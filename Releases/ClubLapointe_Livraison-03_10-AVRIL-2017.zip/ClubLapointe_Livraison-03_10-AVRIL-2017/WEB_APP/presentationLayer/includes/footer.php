</div>

<!-- Footer -->
<footer>
    <div class="container-fluid" id="footer">
        <div class="container">
            <div class="row" >
                <div class="col-lg-12">
                    <p>Copyright &copy; ClubLapointe 2017</p>
                </div>
            </div>
        </div>
    </div>
    <!-- /.row -->
</footer>

</div>
<!-- /.container -->

<!-- jQuery -->
<script src="ressources/js/jquery.js"></script>
<script src="ressources/js/logins.js"></script>
<script src="ressources/js/recherche.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="ressources/js/bootstrap.min.js"></script>


</body>

</html>
